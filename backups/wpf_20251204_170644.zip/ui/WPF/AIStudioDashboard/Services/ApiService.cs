using System.Net.Http;
using Newtonsoft.Json;
using AIStudioDashboard.Models;

namespace AIStudioDashboard.Services;

public interface IApiService
{
    Task<SystemHealth?> GetSystemHealthAsync();
    Task<VideoStats?> GetVideoStatsAsync();
    Task<List<FrameAnalysis>?> GetRecentFramesAsync();
    Task<List<ModelVersion>?> GetModelVersionsAsync();
    Task<TrainingProgress?> GetTrainingProgressAsync();
    Task StartFilteringAsync();
    Task PauseFilteringAsync();
    Task StopFilteringAsync();
}

public class ApiService : IApiService
{
    private readonly HttpClient _httpClient;
    private const string BaseUrl = "http://localhost:8500/api";
    private const string LMStudioUrl = "http://localhost:1234/v1";
    private const string OllamaUrl = "http://localhost:11434";
    
    public ApiService()
    {
        _httpClient = new HttpClient
        {
            Timeout = TimeSpan.FromSeconds(5)
        };
    }
    
    public async Task<SystemHealth?> GetSystemHealthAsync()
    {
        var health = new SystemHealth();
        
        // Check LM Studio
        try
        {
            var response = await _httpClient.GetAsync($"{LMStudioUrl}/models");
            health.LMStudioOnline = response.IsSuccessStatusCode;
            
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                var models = JsonConvert.DeserializeObject<dynamic>(content);
                if (models?.data != null && models.data.Count > 0)
                {
                    health.CurrentModel = models.data[0].id?.ToString() ?? "Unknown";
                }
            }
        }
        catch
        {
            health.LMStudioOnline = false;
        }
        
        // Check Ollama
        try
        {
            var response = await _httpClient.GetAsync($"{OllamaUrl}/api/tags");
            health.OllamaOnline = response.IsSuccessStatusCode;
        }
        catch
        {
            health.OllamaOnline = false;
        }
        
        // Get GPU/Memory stats (would need native interop or PowerShell)
        health.GpuUsage = await GetGpuUsageAsync();
        health.MemoryUsageGB = await GetMemoryUsageAsync();
        health.MemoryTotalGB = 16; // Hardcoded for now
        
        health.LastUpdate = DateTime.Now;
        
        return health;
    }
    
    private async Task<double> GetGpuUsageAsync()
    {
        try
        {
            // Simple check using nvidia-smi (if available)
            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName = "nvidia-smi",
                Arguments = "--query-gpu=utilization.gpu --format=csv,noheader,nounits",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                CreateNoWindow = true
            };
            
            using var process = System.Diagnostics.Process.Start(psi);
            if (process != null)
            {
                var output = await process.StandardOutput.ReadToEndAsync();
                await process.WaitForExitAsync();
                
                if (double.TryParse(output.Trim(), out var usage))
                    return usage;
            }
        }
        catch
        {
            // nvidia-smi not available
        }
        
        return 0;
    }
    
    private async Task<double> GetMemoryUsageAsync()
    {
        try
        {
            var psi = new System.Diagnostics.ProcessStartInfo
            {
                FileName = "nvidia-smi",
                Arguments = "--query-gpu=memory.used --format=csv,noheader,nounits",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                CreateNoWindow = true
            };
            
            using var process = System.Diagnostics.Process.Start(psi);
            if (process != null)
            {
                var output = await process.StandardOutput.ReadToEndAsync();
                await process.WaitForExitAsync();
                
                if (double.TryParse(output.Trim(), out var usage))
                    return usage / 1024.0; // Convert MB to GB
            }
        }
        catch
        {
            // nvidia-smi not available
        }
        
        return 0;
    }
    
    public async Task<VideoStats?> GetVideoStatsAsync()
    {
        try
        {
            var response = await _httpClient.GetAsync($"{BaseUrl}/videos/stats");
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<VideoStats>(content);
            }
        }
        catch { }
        
        return null;
    }
    
    public async Task<List<FrameAnalysis>?> GetRecentFramesAsync()
    {
        try
        {
            var response = await _httpClient.GetAsync($"{BaseUrl}/frames/recent");
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<List<FrameAnalysis>>(content);
            }
        }
        catch { }
        
        return null;
    }
    
    public async Task<List<ModelVersion>?> GetModelVersionsAsync()
    {
        try
        {
            var response = await _httpClient.GetAsync($"{BaseUrl}/models");
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<List<ModelVersion>>(content);
            }
        }
        catch { }
        
        return null;
    }
    
    public async Task<TrainingProgress?> GetTrainingProgressAsync()
    {
        try
        {
            var response = await _httpClient.GetAsync($"{BaseUrl}/training/current");
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<TrainingProgress>(content);
            }
        }
        catch { }
        
        return null;
    }
    
    public async Task StartFilteringAsync()
    {
        await _httpClient.PostAsync($"{BaseUrl}/filter/start", null);
    }
    
    public async Task PauseFilteringAsync()
    {
        await _httpClient.PostAsync($"{BaseUrl}/filter/pause", null);
    }
    
    public async Task StopFilteringAsync()
    {
        await _httpClient.PostAsync($"{BaseUrl}/filter/stop", null);
    }
}
