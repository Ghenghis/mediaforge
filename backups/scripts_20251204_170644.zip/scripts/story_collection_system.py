"""
Story Collection System
- Parse stories (100k-2.5M words)
- Generate 500+ images per collection
- Western, Tribal, Native American themes
- Automatic scene extraction
"""
import sqlite3
import json
import re
import random
from pathlib import Path
from datetime import datetime

DB_PATH = Path(r"c:\Users\Admin\civitai\data\advanced_learning.db")
STORIES_DIR = Path(r"c:\Users\Admin\civitai\data\stories")
STORIES_DIR.mkdir(exist_ok=True)

# Theme configurations
THEMES = {
    "western": {
        "name": "Western",
        "characters": {
            "cowboys": ["cowboy", "rancher", "outlaw", "sheriff", "deputy", "gunslinger", "marshal"],
            "women": ["saloon girl", "pioneer woman", "rancher's wife", "native woman", "outlaw woman"],
            "folk": ["blacksmith", "bartender", "merchant", "preacher", "doctor"]
        },
        "settings": ["saloon", "desert", "ranch", "canyon", "frontier town", "campfire", "stable", "sunset prairie"],
        "clothing": {
            "dressed": ["cowboy hat", "leather vest", "boots", "bandana", "chaps", "duster coat", "flannel shirt"],
            "partial": ["open shirt", "suspenders only", "bathing scene", "sleeping attire"],
            "undressed": ["nude bathing", "intimate scene", "private moment"]
        },
        "style_tags": ["western aesthetic", "wild west", "frontier style", "dusty atmosphere", "golden hour lighting"]
    },
    "tribal": {
        "name": "Tribal",
        "characters": {
            "warriors": ["tribal warrior", "hunter", "chief", "shaman", "scout"],
            "women": ["tribal woman", "priestess", "healer", "dancer", "maiden"],
            "elders": ["elder", "wise woman", "storyteller"]
        },
        "settings": ["jungle", "cave", "waterfall", "sacred grove", "tribal village", "river bank", "ancient temple"],
        "clothing": {
            "dressed": ["tribal attire", "ceremonial dress", "hunting gear", "feather headdress", "bone jewelry"],
            "partial": ["minimal clothing", "ritual attire", "body paint only"],
            "undressed": ["nude ritual", "bathing ceremony", "intimate moment"]
        },
        "style_tags": ["tribal aesthetic", "primal beauty", "exotic", "ceremonial", "dramatic lighting"]
    },
    "native_american": {
        "name": "Native American",
        "tribes": {
            "plains": ["Sioux", "Cheyenne", "Comanche", "Blackfoot", "Crow", "Arapaho"],
            "southwest": ["Apache", "Navajo", "Hopi", "Pueblo", "Zuni"],
            "eastern": ["Cherokee", "Iroquois", "Mohawk", "Seminole", "Creek"],
            "northwest": ["Nez Perce", "Chinook", "Haida", "Tlingit"],
            "california": ["Chumash", "Miwok", "Pomo", "Yurok"]
        },
        "characters": {
            "warriors": ["brave", "war chief", "scout", "hunter"],
            "women": ["native woman", "medicine woman", "chief's daughter", "weaver", "gatherer"],
            "spiritual": ["shaman", "medicine man", "spirit walker", "vision seeker"]
        },
        "settings": ["teepee camp", "prairie", "sacred mountain", "river crossing", "hunting grounds", "council fire"],
        "clothing": {
            "dressed": ["buckskin dress", "war bonnet", "moccasins", "beaded regalia", "buffalo robe"],
            "partial": ["summer attire", "ceremonial paint", "spirit dance attire"],
            "undressed": ["sweat lodge", "vision quest", "private moment"]
        },
        "style_tags": ["native american aesthetic", "spiritual", "connection to nature", "dignified", "proud"]
    }
}


class StoryCollectionSystem:
    def __init__(self):
        self.conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
        self._ensure_tables()
        
    def _ensure_tables(self):
        cursor = self.conn.cursor()
        
        cursor.execute('''CREATE TABLE IF NOT EXISTS story_collections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            collection_name TEXT,
            theme TEXT,
            story_hash TEXT,
            total_scenes INTEGER DEFAULT 0,
            images_generated INTEGER DEFAULT 0,
            target_images INTEGER DEFAULT 500,
            status TEXT DEFAULT 'pending',
            created_at TEXT
        )''')
        
        cursor.execute('''CREATE TABLE IF NOT EXISTS story_scenes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            collection_id INTEGER,
            scene_number INTEGER,
            scene_text TEXT,
            extracted_elements TEXT,
            prompt TEXT,
            images_generated INTEGER DEFAULT 0,
            FOREIGN KEY (collection_id) REFERENCES story_collections(id)
        )''')
        
        cursor.execute('''CREATE TABLE IF NOT EXISTS collection_images (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            collection_id INTEGER,
            scene_id INTEGER,
            image_id TEXT,
            rating REAL DEFAULT 0,
            FOREIGN KEY (collection_id) REFERENCES story_collections(id)
        )''')
        
        self.conn.commit()
        
    # ==================== STORY PARSING ====================
    
    def create_collection(self, name: str, theme: str, story_text: str = None, 
                         story_path: str = None, target_images: int = 500) -> dict:
        """Create new story collection"""
        
        # Load story
        if story_path:
            with open(story_path, 'r', encoding='utf-8') as f:
                story_text = f.read()
        elif not story_text:
            return {'error': 'No story provided'}
            
        word_count = len(story_text.split())
        story_hash = str(hash(story_text[:1000]))[:8]
        
        cursor = self.conn.cursor()
        cursor.execute('''INSERT INTO story_collections 
            (collection_name, theme, story_hash, target_images, created_at)
            VALUES (?, ?, ?, ?, ?)''',
            (name, theme, story_hash, target_images, datetime.now().isoformat()))
        collection_id = cursor.lastrowid
        self.conn.commit()
        
        # Parse scenes
        scenes = self._parse_story(story_text, theme)
        
        # Store scenes
        for i, scene in enumerate(scenes):
            cursor.execute('''INSERT INTO story_scenes 
                (collection_id, scene_number, scene_text, extracted_elements, prompt)
                VALUES (?, ?, ?, ?, ?)''',
                (collection_id, i+1, scene['text'][:500], 
                 json.dumps(scene['elements']), scene['prompt']))
                 
        cursor.execute('UPDATE story_collections SET total_scenes = ? WHERE id = ?',
                      (len(scenes), collection_id))
        self.conn.commit()
        
        return {
            'collection_id': collection_id,
            'name': name,
            'theme': theme,
            'word_count': word_count,
            'scenes_extracted': len(scenes),
            'target_images': target_images
        }
        
    def _parse_story(self, text: str, theme: str) -> list:
        """Parse story into scenes"""
        scenes = []
        theme_config = THEMES.get(theme, THEMES['tribal'])
        
        # Split by paragraphs/scenes
        paragraphs = re.split(r'\n\n+', text)
        
        # Group paragraphs into scenes
        current_scene = []
        for para in paragraphs:
            para = para.strip()
            if not para:
                continue
                
            current_scene.append(para)
            
            # Check for scene break indicators
            if any(indicator in para.lower() for indicator in 
                   ['chapter', 'scene', '***', '---', 'later that', 'the next']):
                if current_scene:
                    scene_text = ' '.join(current_scene)
                    elements = self._extract_elements(scene_text, theme_config)
                    prompt = self._build_prompt(elements, theme_config)
                    scenes.append({
                        'text': scene_text,
                        'elements': elements,
                        'prompt': prompt
                    })
                    current_scene = []
                    
            # Also break on long scenes
            if len(current_scene) >= 5:
                scene_text = ' '.join(current_scene)
                elements = self._extract_elements(scene_text, theme_config)
                prompt = self._build_prompt(elements, theme_config)
                scenes.append({
                    'text': scene_text,
                    'elements': elements,
                    'prompt': prompt
                })
                current_scene = []
                
        # Don't forget last scene
        if current_scene:
            scene_text = ' '.join(current_scene)
            elements = self._extract_elements(scene_text, theme_config)
            prompt = self._build_prompt(elements, theme_config)
            scenes.append({
                'text': scene_text,
                'elements': elements,
                'prompt': prompt
            })
            
        return scenes
        
    def _extract_elements(self, text: str, theme_config: dict) -> dict:
        """Extract visual elements from scene text"""
        text_lower = text.lower()
        elements = {
            'characters': [],
            'setting': None,
            'clothing': 'dressed',
            'mood': 'neutral',
            'time': 'day'
        }
        
        # Find characters
        for char_type, chars in theme_config.get('characters', {}).items():
            for char in chars:
                if char in text_lower:
                    elements['characters'].append(char)
                    
        # Find setting
        for setting in theme_config.get('settings', []):
            if setting in text_lower:
                elements['setting'] = setting
                break
                
        # Determine clothing level
        clothing_keywords = {
            'undressed': ['nude', 'naked', 'bare', 'unclothed', 'intimate', 'passion'],
            'partial': ['bathing', 'undress', 'revealing', 'minimal', 'barely'],
            'dressed': ['dressed', 'wearing', 'clothed', 'outfit']
        }
        
        for level, keywords in clothing_keywords.items():
            if any(kw in text_lower for kw in keywords):
                elements['clothing'] = level
                break
                
        # Mood detection
        mood_keywords = {
            'dramatic': ['battle', 'fight', 'war', 'attack', 'death', 'danger'],
            'romantic': ['love', 'kiss', 'embrace', 'tender', 'passion'],
            'peaceful': ['calm', 'peaceful', 'serene', 'quiet', 'rest'],
            'mysterious': ['secret', 'hidden', 'ancient', 'mystery', 'ritual']
        }
        
        for mood, keywords in mood_keywords.items():
            if any(kw in text_lower for kw in keywords):
                elements['mood'] = mood
                break
                
        # Time of day
        if any(t in text_lower for t in ['night', 'moon', 'stars', 'dark']):
            elements['time'] = 'night'
        elif any(t in text_lower for t in ['sunset', 'dusk', 'evening']):
            elements['time'] = 'sunset'
        elif any(t in text_lower for t in ['dawn', 'sunrise', 'morning']):
            elements['time'] = 'dawn'
            
        return elements
        
    def _build_prompt(self, elements: dict, theme_config: dict) -> str:
        """Build image prompt from extracted elements"""
        parts = ["masterpiece", "best quality", "ultra detailed", "8k resolution",
                 "photorealistic", "RAW photo", "sharp focus"]
        
        # Add theme style
        parts.extend(theme_config.get('style_tags', []))
        
        # Add characters
        if elements['characters']:
            char = random.choice(elements['characters'])
            parts.append(f"({char}:1.3)")
        else:
            # Default character
            char_types = list(theme_config.get('characters', {}).values())
            if char_types:
                chars = random.choice(char_types)
                if chars:
                    parts.append(f"({random.choice(chars)}:1.3)")
                    
        # Add body details
        parts.extend([
            "(adult woman:1.3)", 
            random.choice(["petite", "slim", "athletic", "toned"]),
            random.choice(["A cup", "B cup", "small bust"]),
            random.choice(["perky", "firm", "natural"])
        ])
        
        # Add setting
        if elements['setting']:
            parts.append(f"({elements['setting']}:1.2)")
        else:
            settings = theme_config.get('settings', ['outdoor'])
            parts.append(f"({random.choice(settings)}:1.2)")
            
        # Add clothing
        clothing_level = elements['clothing']
        clothing_options = theme_config.get('clothing', {}).get(clothing_level, [])
        if clothing_options:
            parts.append(random.choice(clothing_options))
            
        # Add mood lighting
        mood_lighting = {
            'dramatic': 'dramatic lighting, high contrast',
            'romantic': 'soft lighting, warm tones',
            'peaceful': 'natural lighting, soft shadows',
            'mysterious': 'moody lighting, atmospheric'
        }
        parts.append(mood_lighting.get(elements['mood'], 'natural lighting'))
        
        # Time of day
        time_lighting = {
            'night': 'moonlight, night scene',
            'sunset': 'golden hour, sunset colors',
            'dawn': 'dawn lighting, soft morning light',
            'day': 'daylight, clear lighting'
        }
        parts.append(time_lighting.get(elements['time'], 'daylight'))
        
        return ", ".join(parts)
        
    # ==================== GENERATION ====================
    
    def get_collection_status(self, collection_id: int) -> dict:
        cursor = self.conn.cursor()
        cursor.execute('''SELECT collection_name, theme, total_scenes, 
            images_generated, target_images, status FROM story_collections WHERE id = ?''',
            (collection_id,))
        result = cursor.fetchone()
        
        if not result:
            return {'error': 'Collection not found'}
            
        return {
            'name': result[0],
            'theme': result[1],
            'scenes': result[2],
            'images_generated': result[3],
            'target': result[4],
            'status': result[5],
            'progress': round((result[3] / result[4]) * 100, 1) if result[4] else 0
        }
        
    def get_next_scene_prompt(self, collection_id: int) -> dict:
        """Get next scene to generate"""
        cursor = self.conn.cursor()
        cursor.execute('''SELECT id, scene_number, prompt, extracted_elements 
            FROM story_scenes 
            WHERE collection_id = ? AND images_generated < 5
            ORDER BY scene_number
            LIMIT 1''', (collection_id,))
        result = cursor.fetchone()
        
        if not result:
            return {'status': 'complete', 'message': 'All scenes generated'}
            
        return {
            'scene_id': result[0],
            'scene_number': result[1],
            'prompt': result[2],
            'elements': json.loads(result[3])
        }
        
    def close(self):
        self.conn.close()


# ==================== THEME BROWSER ====================
def list_themes():
    """List all available themes"""
    print("\n📚 AVAILABLE THEMES:\n")
    
    for theme_key, theme in THEMES.items():
        print(f"🎬 {theme['name'].upper()}")
        print(f"   Key: {theme_key}")
        
        if 'tribes' in theme:
            print(f"   Tribes: {sum(len(v) for v in theme['tribes'].values())} total")
            for region, tribes in theme['tribes'].items():
                print(f"      {region}: {', '.join(tribes[:3])}...")
                
        if 'characters' in theme:
            total_chars = sum(len(v) for v in theme['characters'].values())
            print(f"   Characters: {total_chars} types")
            
        print(f"   Settings: {len(theme.get('settings', []))} options")
        print(f"   Clothing levels: dressed, partial, undressed")
        print()


# ==================== TEST ====================
def test_system():
    print("="*60)
    print("  STORY COLLECTION SYSTEM TEST")
    print("="*60)
    
    list_themes()
    
    scs = StoryCollectionSystem()
    
    # Test story
    test_story = """
    Chapter 1: The Warrior's Dawn
    
    The sun rose over the prairie as Running Wolf prepared for the hunt.
    His muscular form silhouetted against the golden horizon.
    
    ***
    
    Later that morning, he encountered a beautiful woman bathing in the river.
    She was the chief's daughter, known for her striking features and grace.
    
    ---
    
    That night, the tribal council gathered around the sacred fire.
    The shaman performed an ancient ritual under the moonlight.
    The drums echoed through the canyon as dancers moved in ceremony.
    """
    
    print("\n📝 Creating test collection...")
    result = scs.create_collection(
        name="Test Native Story",
        theme="native_american",
        story_text=test_story,
        target_images=50
    )
    
    print(f"   Collection ID: {result['collection_id']}")
    print(f"   Scenes extracted: {result['scenes_extracted']}")
    print(f"   Target images: {result['target_images']}")
    
    # Get first scene
    print("\n📸 First scene prompt:")
    scene = scs.get_next_scene_prompt(result['collection_id'])
    print(f"   Scene {scene['scene_number']}:")
    print(f"   {scene['prompt'][:100]}...")
    
    print("\n✅ Story Collection System operational!")
    
    scs.close()


if __name__ == "__main__":
    test_system()
