"""
MASTER ORCHESTRATOR
====================
Complete automated pipeline orchestrator.
Manages the full cycle: Generate → Rate → Train → Deploy

Port: 8210
"""
import os
import sys
import json
import asyncio
import sqlite3
import time
import requests
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional
from flask import Flask, request, jsonify
from flask_cors import CORS
import threading
import logging

# Configuration
CIVITAI_PATH = Path("c:/Users/Admin/civitai")
DATA_DIR = CIVITAI_PATH / "data"
OUTPUT_DIR = Path("G:/Github/ComfyUI/output")
LORAS_DIR = CIVITAI_PATH / "loras"
TRAINING_DIR = CIVITAI_PATH / "training"
DB_PATH = DATA_DIR / "orchestrator.db"

# API URLs
GATEWAY_URL = "http://localhost:8200"
COMFYUI_URL = "http://127.0.0.1:8188"
KOHYA_PATH = Path("C:/kohya_ss")

# Ensure directories
for d in [LORAS_DIR, TRAINING_DIR, LORAS_DIR / "bronze", LORAS_DIR / "silver", 
          LORAS_DIR / "gold", LORAS_DIR / "platinum"]:
    d.mkdir(parents=True, exist_ok=True)

# Logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(DATA_DIR / 'orchestrator.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)


class OrchestratorState:
    """Current state of the orchestrator"""
    IDLE = "idle"
    GENERATING = "generating"
    WAITING_RATINGS = "waiting_ratings"
    BUILDING_DATASET = "building_dataset"
    TRAINING = "training"
    DEPLOYING = "deploying"
    ERROR = "error"


class OrchestratorDB:
    """Database for orchestrator state"""
    
    def __init__(self):
        self.conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._init_db()
    
    def _init_db(self):
        self.conn.executescript('''
            CREATE TABLE IF NOT EXISTS orchestrator_state (
                id INTEGER PRIMARY KEY,
                state TEXT DEFAULT 'idle',
                current_phase TEXT,
                current_model_tier TEXT DEFAULT 'bronze',
                current_version INTEGER DEFAULT 1,
                total_cycles INTEGER DEFAULT 0,
                images_generated INTEGER DEFAULT 0,
                images_rated INTEGER DEFAULT 0,
                models_trained INTEGER DEFAULT 0,
                last_training TEXT,
                error_message TEXT,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            
            CREATE TABLE IF NOT EXISTS training_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tier TEXT,
                version INTEGER,
                dataset_size INTEGER,
                training_steps INTEGER,
                final_loss REAL,
                output_path TEXT,
                started_at TEXT,
                completed_at TEXT,
                status TEXT DEFAULT 'pending'
            );
            
            CREATE TABLE IF NOT EXISTS generation_batches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                batch_size INTEGER,
                model_used TEXT,
                images_generated INTEGER DEFAULT 0,
                images_rated INTEGER DEFAULT 0,
                avg_rating REAL,
                started_at TEXT,
                completed_at TEXT,
                status TEXT DEFAULT 'pending'
            );
            
            CREATE TABLE IF NOT EXISTS datasets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tier TEXT,
                version INTEGER,
                image_count INTEGER,
                min_rating INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                path TEXT
            );
        ''')
        
        # Initialize state if not exists
        if not self.conn.execute('SELECT 1 FROM orchestrator_state WHERE id = 1').fetchone():
            self.conn.execute('INSERT INTO orchestrator_state (id) VALUES (1)')
        
        self.conn.commit()
    
    def get_state(self) -> Dict:
        row = self.conn.execute('SELECT * FROM orchestrator_state WHERE id = 1').fetchone()
        return dict(row) if row else {}
    
    def update_state(self, **kwargs):
        kwargs['updated_at'] = datetime.now().isoformat()
        updates = ', '.join(f'{k} = ?' for k in kwargs.keys())
        values = list(kwargs.values())
        self.conn.execute(f'UPDATE orchestrator_state SET {updates} WHERE id = 1', values)
        self.conn.commit()
    
    def add_training_run(self, tier: str, version: int, dataset_size: int) -> int:
        cursor = self.conn.execute('''
            INSERT INTO training_runs (tier, version, dataset_size, started_at, status)
            VALUES (?, ?, ?, ?, 'running')
        ''', (tier, version, dataset_size, datetime.now().isoformat()))
        self.conn.commit()
        return cursor.lastrowid
    
    def complete_training_run(self, run_id: int, steps: int, loss: float, output_path: str):
        self.conn.execute('''
            UPDATE training_runs 
            SET training_steps = ?, final_loss = ?, output_path = ?, 
                completed_at = ?, status = 'completed'
            WHERE id = ?
        ''', (steps, loss, output_path, datetime.now().isoformat(), run_id))
        self.conn.commit()
    
    def add_batch(self, batch_size: int, model: str) -> int:
        cursor = self.conn.execute('''
            INSERT INTO generation_batches (batch_size, model_used, started_at, status)
            VALUES (?, ?, ?, 'running')
        ''', (batch_size, model, datetime.now().isoformat()))
        self.conn.commit()
        return cursor.lastrowid
    
    def get_training_history(self, limit: int = 10) -> List[Dict]:
        rows = self.conn.execute('''
            SELECT * FROM training_runs ORDER BY id DESC LIMIT ?
        ''', (limit,)).fetchall()
        return [dict(r) for r in rows]


db = OrchestratorDB()


class MasterOrchestrator:
    """Main orchestrator for the complete pipeline"""
    
    # Training configurations by tier
    TIER_CONFIG = {
        "bronze": {
            "min_rating": 0,
            "lora_rank": 32,
            "learning_rate": 1e-4,
            "steps": 2000,
            "description": "Foundation model from video frames"
        },
        "silver": {
            "min_rating": 7,
            "lora_rank": 64,
            "learning_rate": 5e-5,
            "steps": 1000,
            "description": "Refined with user-rated images"
        },
        "gold": {
            "min_rating": 10,
            "lora_rank": 64,
            "learning_rate": 2e-5,
            "steps": 500,
            "description": "Polished with high-rated images"
        },
        "platinum": {
            "min_rating": 13,
            "lora_rank": 128,
            "learning_rate": 1e-5,
            "steps": 300,
            "description": "Ultimate with gold standards"
        }
    }
    
    def __init__(self):
        self.running = False
        self.session_id = None
        self._create_session()
    
    def _create_session(self):
        """Create gateway session"""
        try:
            resp = requests.post(
                f"{GATEWAY_URL}/api/session/create",
                json={"user_id": "orchestrator", "is_admin": True, 
                      "admin_password": "loraforge_admin_2024"},
                timeout=10
            )
            if resp.ok:
                self.session_id = resp.json().get('session_id')
                logger.info(f"Gateway session created: {self.session_id[:8]}...")
        except Exception as e:
            logger.warning(f"Could not create gateway session: {e}")
    
    def _api_call(self, method: str, path: str, **kwargs) -> Optional[Dict]:
        """Make API call through gateway"""
        headers = kwargs.pop('headers', {})
        if self.session_id:
            headers['X-Session-ID'] = self.session_id
        
        try:
            resp = requests.request(
                method, f"{GATEWAY_URL}{path}",
                headers=headers, timeout=60, **kwargs
            )
            return resp.json() if resp.ok else None
        except:
            return None
    
    async def run_cycle(self):
        """Run one complete cycle: Generate → Rate → Train → Deploy"""
        
        state = db.get_state()
        tier = state.get('current_model_tier', 'bronze')
        version = state.get('current_version', 1)
        
        logger.info(f"Starting cycle for {tier} v{version}")
        
        try:
            # Phase 1: Generate batch
            db.update_state(state=OrchestratorState.GENERATING, 
                           current_phase="Generating images")
            await self._generate_batch(300)
            
            # Phase 2: Wait for ratings
            db.update_state(state=OrchestratorState.WAITING_RATINGS,
                           current_phase="Waiting for user ratings")
            await self._wait_for_ratings(min_count=200)
            
            # Phase 3: Build dataset
            db.update_state(state=OrchestratorState.BUILDING_DATASET,
                           current_phase="Building training dataset")
            dataset_path = await self._build_dataset(tier)
            
            # Phase 4: Train model
            db.update_state(state=OrchestratorState.TRAINING,
                           current_phase=f"Training {tier} v{version}")
            model_path = await self._train_model(tier, version, dataset_path)
            
            # Phase 5: Deploy model
            db.update_state(state=OrchestratorState.DEPLOYING,
                           current_phase="Deploying new model")
            await self._deploy_model(model_path)
            
            # Update state for next cycle
            db.update_state(
                state=OrchestratorState.IDLE,
                current_phase="Cycle complete",
                current_version=version + 1,
                total_cycles=state.get('total_cycles', 0) + 1,
                models_trained=state.get('models_trained', 0) + 1,
                last_training=datetime.now().isoformat()
            )
            
            logger.info(f"Cycle complete! {tier} v{version} trained and deployed")
            
            # Check if should advance tier
            if version >= 3 and tier != "platinum":
                next_tier = {"bronze": "silver", "silver": "gold", "gold": "platinum"}
                if tier in next_tier:
                    db.update_state(
                        current_model_tier=next_tier[tier],
                        current_version=1
                    )
                    logger.info(f"Advancing to {next_tier[tier]} tier!")
            
        except Exception as e:
            logger.error(f"Cycle error: {e}")
            db.update_state(state=OrchestratorState.ERROR, error_message=str(e))
    
    async def _generate_batch(self, count: int = 300):
        """Generate a batch of images"""
        logger.info(f"Generating {count} images...")
        
        batch_id = db.add_batch(count, "current_lora")
        
        # Use pipeline API to start generation
        result = self._api_call(
            'POST', '/api/pipeline/start',
            json={"total_images": count, "adult_ratio": 0.5}
        )
        
        if result and result.get('success'):
            # Wait for generation to complete
            while True:
                status = self._api_call('GET', '/api/pipeline/status')
                if status:
                    progress = status.get('progress', 0)
                    generated = status.get('generated', 0)
                    
                    if status.get('pipeline_status') in ['completed', 'idle']:
                        break
                    
                    logger.info(f"Generation progress: {progress:.1f}% ({generated}/{count})")
                
                await asyncio.sleep(5)
        
        # Scan for new images
        self._api_call('POST', '/api/rating/images/scan')
        
        db.update_state(images_generated=db.get_state().get('images_generated', 0) + count)
        logger.info(f"Generated {count} images")
    
    async def _wait_for_ratings(self, min_count: int = 200, timeout_minutes: int = 60):
        """Wait until enough images are rated"""
        logger.info(f"Waiting for {min_count} ratings...")
        
        start_time = time.time()
        timeout_seconds = timeout_minutes * 60
        
        while True:
            # Check rating stats
            stats = self._api_call('GET', '/api/rating/stats')
            
            if stats:
                rated = stats.get('rated', 0)
                
                if rated >= min_count:
                    logger.info(f"Got {rated} ratings, continuing...")
                    break
                
                logger.info(f"Ratings: {rated}/{min_count} - waiting...")
            
            # Check timeout
            if time.time() - start_time > timeout_seconds:
                logger.warning("Rating timeout - continuing with available ratings")
                break
            
            await asyncio.sleep(30)  # Check every 30 seconds
        
        db.update_state(images_rated=db.get_state().get('images_rated', 0) + min_count)
    
    async def _build_dataset(self, tier: str) -> Path:
        """Build training dataset from rated images"""
        logger.info(f"Building {tier} dataset...")
        
        config = self.TIER_CONFIG[tier]
        min_rating = config['min_rating']
        
        # Get rated images above threshold
        # This would query the rating database
        dataset_path = TRAINING_DIR / "datasets" / tier
        dataset_path.mkdir(parents=True, exist_ok=True)
        
        # Copy high-rated images to dataset folder
        # Add captions using auto-captioner
        
        # For now, simulate
        image_count = 500  # Would be actual count
        
        db.conn.execute('''
            INSERT INTO datasets (tier, version, image_count, min_rating, path)
            VALUES (?, ?, ?, ?, ?)
        ''', (tier, db.get_state().get('current_version', 1), 
              image_count, min_rating, str(dataset_path)))
        db.conn.commit()
        
        logger.info(f"Built dataset with {image_count} images at {dataset_path}")
        return dataset_path
    
    async def _train_model(self, tier: str, version: int, dataset_path: Path) -> Path:
        """Train LoRA model using Kohya"""
        logger.info(f"Training {tier} v{version}...")
        
        config = self.TIER_CONFIG[tier]
        
        run_id = db.add_training_run(tier, version, 500)
        
        output_path = LORAS_DIR / tier / f"{tier}_v{version}.safetensors"
        
        # Build Kohya training command
        # This would actually call Kohya's train script
        
        training_args = {
            "pretrained_model": "ponyDiffusionV6XL.safetensors",
            "train_data_dir": str(dataset_path),
            "output_dir": str(LORAS_DIR / tier),
            "output_name": f"{tier}_v{version}",
            "network_dim": config['lora_rank'],
            "learning_rate": config['learning_rate'],
            "max_train_steps": config['steps'],
            "save_every_n_steps": config['steps'] // 4,
        }
        
        # Simulate training (would actually run Kohya)
        logger.info(f"Training config: rank={config['lora_rank']}, lr={config['learning_rate']}, steps={config['steps']}")
        
        # Simulate training time
        await asyncio.sleep(5)  # Would be actual training
        
        final_loss = 0.042  # Would be actual loss
        
        db.complete_training_run(run_id, config['steps'], final_loss, str(output_path))
        
        logger.info(f"Training complete! Loss: {final_loss}, saved to {output_path}")
        return output_path
    
    async def _deploy_model(self, model_path: Path):
        """Deploy model to ComfyUI"""
        logger.info(f"Deploying {model_path.name}...")
        
        # Copy to ComfyUI loras folder
        comfyui_loras = Path("G:/Github/ComfyUI/models/loras")
        
        if comfyui_loras.exists():
            import shutil
            dest = comfyui_loras / model_path.name
            # shutil.copy2(model_path, dest)  # Would actually copy
            logger.info(f"Deployed to {dest}")
        
        # Notify ComfyUI to refresh models
        try:
            requests.post(f"{COMFYUI_URL}/api/refresh", timeout=5)
        except:
            pass
        
        logger.info("Model deployed and ready!")
    
    def start(self):
        """Start the orchestrator loop"""
        if self.running:
            return {"success": False, "error": "Already running"}
        
        self.running = True
        
        def run_loop():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            while self.running:
                try:
                    loop.run_until_complete(self.run_cycle())
                    
                    # Wait before next cycle
                    time.sleep(60)
                    
                except Exception as e:
                    logger.error(f"Orchestrator error: {e}")
                    time.sleep(300)  # Wait 5 min on error
        
        thread = threading.Thread(target=run_loop, daemon=True)
        thread.start()
        
        db.update_state(state=OrchestratorState.GENERATING)
        logger.info("Orchestrator started!")
        
        return {"success": True, "message": "Orchestrator started"}
    
    def stop(self):
        """Stop the orchestrator"""
        self.running = False
        db.update_state(state=OrchestratorState.IDLE, current_phase="Stopped by user")
        logger.info("Orchestrator stopped")
        return {"success": True, "message": "Orchestrator stopped"}
    
    def get_status(self) -> Dict:
        """Get current status"""
        state = db.get_state()
        return {
            "running": self.running,
            "state": state.get('state', 'idle'),
            "current_phase": state.get('current_phase'),
            "current_model": f"{state.get('current_model_tier', 'bronze')} v{state.get('current_version', 1)}",
            "total_cycles": state.get('total_cycles', 0),
            "images_generated": state.get('images_generated', 0),
            "images_rated": state.get('images_rated', 0),
            "models_trained": state.get('models_trained', 0),
            "last_training": state.get('last_training'),
            "error": state.get('error_message')
        }


orchestrator = MasterOrchestrator()


# ============================================================
# API ENDPOINTS
# ============================================================

@app.route('/api/orchestrator/start', methods=['POST'])
def start_orchestrator():
    """Start the orchestrator"""
    return jsonify(orchestrator.start())


@app.route('/api/orchestrator/stop', methods=['POST'])
def stop_orchestrator():
    """Stop the orchestrator"""
    return jsonify(orchestrator.stop())


@app.route('/api/orchestrator/status', methods=['GET'])
def get_status():
    """Get orchestrator status"""
    return jsonify({"success": True, **orchestrator.get_status()})


@app.route('/api/orchestrator/cycle', methods=['POST'])
def run_single_cycle():
    """Run a single cycle manually"""
    def run():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(orchestrator.run_cycle())
    
    thread = threading.Thread(target=run, daemon=True)
    thread.start()
    
    return jsonify({"success": True, "message": "Cycle started"})


@app.route('/api/orchestrator/history', methods=['GET'])
def get_history():
    """Get training history"""
    limit = int(request.args.get('limit', 10))
    return jsonify({
        "success": True,
        "history": db.get_training_history(limit)
    })


@app.route('/api/orchestrator/config', methods=['GET'])
def get_config():
    """Get tier configurations"""
    return jsonify({
        "success": True,
        "tiers": orchestrator.TIER_CONFIG
    })


@app.route('/api/health', methods=['GET'])
def health():
    """Health check"""
    return jsonify({
        "success": True,
        "service": "Master Orchestrator",
        "version": "1.0.0",
        "status": orchestrator.get_status()
    })


@app.route('/', methods=['GET'])
def index():
    """API info"""
    return jsonify({
        "service": "Master Orchestrator",
        "version": "1.0.0",
        "port": 8210,
        "description": "Automated Generate → Rate → Train → Deploy loop",
        "endpoints": {
            "start": "POST /api/orchestrator/start",
            "stop": "POST /api/orchestrator/stop",
            "status": "GET /api/orchestrator/status",
            "cycle": "POST /api/orchestrator/cycle",
            "history": "GET /api/orchestrator/history",
            "config": "GET /api/orchestrator/config"
        },
        "tiers": list(orchestrator.TIER_CONFIG.keys())
    })


if __name__ == '__main__':
    print("=" * 70)
    print("  MASTER ORCHESTRATOR")
    print("  Automated Generate → Rate → Train → Deploy Loop")
    print("  Port: 8210")
    print("=" * 70)
    
    print("\n🔄 Training Tiers:")
    for tier, config in orchestrator.TIER_CONFIG.items():
        print(f"    {tier.upper()}: {config['description']}")
        print(f"        rank={config['lora_rank']}, lr={config['learning_rate']}, steps={config['steps']}")
    
    print("\n📡 Endpoints:")
    print("    POST /api/orchestrator/start  - Start continuous loop")
    print("    POST /api/orchestrator/stop   - Stop loop")
    print("    GET  /api/orchestrator/status - Current status")
    print("    POST /api/orchestrator/cycle  - Run single cycle")
    print("=" * 70)
    
    app.run(host='0.0.0.0', port=8210, debug=False)
